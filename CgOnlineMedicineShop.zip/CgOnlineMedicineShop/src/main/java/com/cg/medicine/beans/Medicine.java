package com.cg.medicine.beans;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.SequenceGenerator;
@Entity
@SequenceGenerator(name="sequenceMedicine",initialValue=1101011,allocationSize=1)
public class Medicine {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="sequenceMedicine")
	private int medicineId;
	private String medicineName;
	private double  medicinePrice;
	private int stockQuantity;
	private String dateOfManufacturer;
	private String dateOfExpiry;
	private String manufacturerCompany;
	@JoinColumn(name="customerId")
	@MapKey
	@ManyToOne
	private Customer customer;
	public Medicine() {
		super();
	}
	public Medicine(int medicineId, String medicineName, double medicinePrice, int stockQuantity,
			String dateOfManufacturer, String dateOfExpiry, String manufacturerCompany, Customer customer) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.medicinePrice = medicinePrice;
		this.stockQuantity = stockQuantity;
		this.dateOfManufacturer = dateOfManufacturer;
		this.dateOfExpiry = dateOfExpiry;
		this.manufacturerCompany = manufacturerCompany;
		this.customer = customer;
	}
	public int getMedicineId() {
		return medicineId;
	}
	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public double getMedicinePrice() {
		return medicinePrice;
	}
	public void setMedicinePrice(double medicinePrice) {
		this.medicinePrice = medicinePrice;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	public String getDateOfManufacturer() {
		return dateOfManufacturer;
	}
	public void setDateOfManufacturer(String dateOfManufacturer) {
		this.dateOfManufacturer = dateOfManufacturer;
	}
	public String getDateOfExpiry() {
		return dateOfExpiry;
	}
	public void setDateOfExpiry(String dateOfExpiry) {
		this.dateOfExpiry = dateOfExpiry;
	}
	public String getManufacturerCompany() {
		return manufacturerCompany;
	}
	public void setManufacturerCompany(String manufacturerCompany) {
		this.manufacturerCompany = manufacturerCompany;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((customer == null) ? 0 : customer.hashCode());
		result = prime * result + ((dateOfExpiry == null) ? 0 : dateOfExpiry.hashCode());
		result = prime * result + ((dateOfManufacturer == null) ? 0 : dateOfManufacturer.hashCode());
		result = prime * result + ((manufacturerCompany == null) ? 0 : manufacturerCompany.hashCode());
		result = prime * result + medicineId;
		result = prime * result + ((medicineName == null) ? 0 : medicineName.hashCode());
		long temp;
		temp = Double.doubleToLongBits(medicinePrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + stockQuantity;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Medicine other = (Medicine) obj;
		if (customer == null) {
			if (other.customer != null)
				return false;
		} else if (!customer.equals(other.customer))
			return false;
		if (dateOfExpiry == null) {
			if (other.dateOfExpiry != null)
				return false;
		} else if (!dateOfExpiry.equals(other.dateOfExpiry))
			return false;
		if (dateOfManufacturer == null) {
			if (other.dateOfManufacturer != null)
				return false;
		} else if (!dateOfManufacturer.equals(other.dateOfManufacturer))
			return false;
		if (manufacturerCompany == null) {
			if (other.manufacturerCompany != null)
				return false;
		} else if (!manufacturerCompany.equals(other.manufacturerCompany))
			return false;
		if (medicineId != other.medicineId)
			return false;
		if (medicineName == null) {
			if (other.medicineName != null)
				return false;
		} else if (!medicineName.equals(other.medicineName))
			return false;
		if (Double.doubleToLongBits(medicinePrice) != Double.doubleToLongBits(other.medicinePrice))
			return false;
		if (stockQuantity != other.stockQuantity)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Medicine [medicineId=" + medicineId + ", medicineName=" + medicineName + ", medicinePrice="
				+ medicinePrice + ", stockQuantity=" + stockQuantity + ", dateOfManufacturer=" + dateOfManufacturer
				+ ", dateOfExpiry=" + dateOfExpiry + ", manufacturerCompany=" + manufacturerCompany + ", customer="
				+ customer + "]";
	}
}
