package com.cg.medicine.services;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.medicine.beans.Customer;
import com.cg.medicine.beans.Medicine;
import com.cg.medicine.daoservices.CustomerDAOServices;
import com.cg.medicine.daoservices.MedicineDAOServices;
import com.cg.medicine.exceptions.CustomerNotFoundException;
import com.cg.medicine.exceptions.InsufficientStockException;
import com.cg.medicine.exceptions.MedicineNotFoundException;
import com.cg.medicine.exceptions.MedicineServicesDownExcepton;
import com.cg.medicine.exceptions.OutOfStockException;
@Component("medicineServices")
public class MedicineServicesImpl  implements MedicineServices{
	@Autowired
	private CustomerDAOServices customerDAOServices;
	@Autowired
	private MedicineDAOServices medicineDAOServices;
	@Override
	public Customer acceptCustomerDetails(Customer customer) throws MedicineServicesDownExcepton{
		customer=customerDAOServices.save(customer);
		return customer;
	}

	@Override
	public Medicine acceptMedicineDetails(Medicine medicine) throws MedicineServicesDownExcepton{
		medicine=medicineDAOServices.save(medicine);
		return medicine;
	}

	@Override
	public boolean buyMedicine(int customerId,String medicineName, int quantity) throws MedicineServicesDownExcepton,MedicineNotFoundException, OutOfStockException, InsufficientStockException, CustomerNotFoundException {
		Customer customer=customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		Medicine medicine=medicineDAOServices.findMedicine(medicineName);
		if(medicine==null)
			throw new MedicineNotFoundException();
		if(medicine.getStockQuantity()<=0)
			throw new OutOfStockException();
		if(medicine.getStockQuantity()<quantity)
			throw new InsufficientStockException();
		medicine.setStockQuantity(medicine.getStockQuantity()-quantity);
		medicineDAOServices.save(medicine);

		medicine.setStockQuantity(quantity);
		Map<Integer, Medicine> mapMedicine=new HashMap<>();
		mapMedicine.put(medicine.getMedicineId(), medicine);
		customer.setMedicine(mapMedicine);
		customerDAOServices.save(customer);
		return true;
	}

	@Override
	public List<Medicine> viewAllMedicine() {
		return medicineDAOServices.findAll();
	}

	@Override
	public List<Customer> viewAllCustomer() {
		return 	customerDAOServices.findAll();
	}

	@Override
	public boolean deleteMedicine(int medicineId) throws MedicineNotFoundException {
		medicineDAOServices.findById(medicineId).orElseThrow(()->new MedicineNotFoundException());
		medicineDAOServices.deleteById(medicineId);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerId) throws CustomerNotFoundException {
		customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		customerDAOServices.deleteById(customerId);
		return true;
	}

	@Override
	public boolean updateMedicine(int medicineId, int quantity) throws MedicineNotFoundException {
		Medicine medicine=medicineDAOServices.findById(medicineId).orElseThrow(()->new MedicineNotFoundException());
		medicine.setStockQuantity(medicine.getStockQuantity()+quantity);
		medicineDAOServices.save(medicine);
		return true;
	}

	@Override
	public boolean updateCustomerMobileNo(int customerId, long mobileNo) throws CustomerNotFoundException {
		Customer customer=customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		customer.setMobileNo(mobileNo);
		customerDAOServices.save(customer);
		return true;
	}

	@Override
	public boolean updateCustomerAddress(Customer customer) throws CustomerNotFoundException {
		Customer customer1=customerDAOServices.findById(customer.getCustomerId()).orElseThrow(()->new CustomerNotFoundException());
		customer1.setAddress(customer.getAddress());
		customerDAOServices.save(customer1);
		return true;
	}

	@Override
	public List<Medicine> viewCustomerMedicine(int customerId) throws CustomerNotFoundException {
		Customer customer=customerDAOServices.findById(customerId).orElseThrow(()->new CustomerNotFoundException());
		Map<Integer, Medicine> mapMedicine=customer.getMedicine();
		List<Medicine> listMedicine=new ArrayList<>(mapMedicine.values());
		return listMedicine;
	}
}