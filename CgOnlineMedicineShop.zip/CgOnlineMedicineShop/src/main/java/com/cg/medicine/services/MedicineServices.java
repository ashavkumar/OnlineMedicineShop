package com.cg.medicine.services;
import java.util.List;
import com.cg.medicine.beans.Customer;
import com.cg.medicine.beans.Medicine;
import com.cg.medicine.exceptions.CustomerNotFoundException;
import com.cg.medicine.exceptions.InsufficientStockException;
import com.cg.medicine.exceptions.MedicineNotFoundException;
import com.cg.medicine.exceptions.MedicineServicesDownExcepton;
import com.cg.medicine.exceptions.OutOfStockException;
public interface MedicineServices {
	public Customer acceptCustomerDetails(Customer customer) throws MedicineServicesDownExcepton;
	public Medicine acceptMedicineDetails(Medicine medicine) throws MedicineServicesDownExcepton;
	public boolean buyMedicine(int customerId,String medicineName,int quantity) throws MedicineNotFoundException, OutOfStockException, InsufficientStockException, MedicineServicesDownExcepton, CustomerNotFoundException;
	public List<Medicine> viewCustomerMedicine(int customerId) throws CustomerNotFoundException;
	public List<Medicine> viewAllMedicine();
	public List<Customer> viewAllCustomer();
	public boolean deleteMedicine(int medicineId) throws MedicineNotFoundException;
	public boolean deleteCustomer(int CustomerId) throws CustomerNotFoundException;
	public boolean updateMedicine(int medicineId,int quantity) throws MedicineNotFoundException;
	public boolean updateCustomerMobileNo(int customerId,long mobileNo) throws CustomerNotFoundException;
	public boolean updateCustomerAddress(Customer customer) throws CustomerNotFoundException;
}
