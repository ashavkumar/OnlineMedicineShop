package com.cg.medicine.beans;
import java.util.Map;
import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.validation.Valid;
@SequenceGenerator(name="sequenceCustomer",initialValue=1001,allocationSize=1)
@Entity
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="sequenceCustomer")
	private int customerId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String dateOfBirth;
	private Long mobileNo;
	@Valid
	@Embedded
	private Address address;
	@MapKey
	@OneToMany(mappedBy="customer",cascade=CascadeType.ALL,fetch = FetchType.EAGER,orphanRemoval=true)
	private Map<Integer, Medicine> medicine;
	public Customer() {
		super();
	}
	public Customer(int customerId, String firstName, String lastName, String emailId, String dateOfBirth,
			Long mobileNo, @Valid Address address, Map<Integer, Medicine> medicine) {
		super();
		this.customerId = customerId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.dateOfBirth = dateOfBirth;
		this.mobileNo = mobileNo;
		this.address = address;
		this.medicine = medicine;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Long getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public Map<Integer, Medicine> getMedicine() {
		return medicine;
	}
	public void setMedicine(Map<Integer, Medicine> medicine) {
		this.medicine = medicine;
	}

}
