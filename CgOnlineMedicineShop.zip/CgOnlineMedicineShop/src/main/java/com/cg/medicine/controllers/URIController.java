package com.cg.medicine.controllers;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.medicine.beans.Customer;
import com.cg.medicine.beans.Medicine;
@Controller
public class URIController {
	Customer custmer;
	Medicine medicine;
	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
	@ModelAttribute
	public Medicine getMedicine() {
		return new Medicine();
	}
	@RequestMapping({"/","/home"})
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/customer")
	public String getCustomerIndexPage() {
		return "customerIndexPage";
	}
	@RequestMapping("/admin")
	public String getAdminIndexPage() {
		return "adminIndexPage";
	}
	@RequestMapping("/register")
	public String getCustomerDetailsPage() {
		return "getCustomerDetailsPage";
	}
	@RequestMapping("/buy")
	public String getMedicineNamePage() {
		return "getMedicineNamePage";
	}
	@RequestMapping("/registerMedicine")
	public String getMedicineDetailsPage() {
		return "getMedicineDetailsPage";
	}
	@RequestMapping("/customerMedicine")
	public String getCustomerIdPage() {
		return  "getCustomerIdPage"; 
	}
	@RequestMapping("/delete")
	public String getDeleteCustomerIdPage() {
		return "getDeleteCustomerIdPage";
	}
	@RequestMapping("/updateAddress")
	public String getUpdateAddressPage() {
		return "getUpdateAddressPage";
	}
	@RequestMapping("/updateMobile")
	public String getUpdateMobilePage() {
		return "getUpdateMobilePage";
	}
	@RequestMapping("/deleteMedicine")
	public String getDeleteMedicinePage() {
		return "getMedicineDeleteDetailsPage";
	}
	@RequestMapping("/updateMedicine")
	public String getUpdateMedicinePage() {
		return "getUpdateMedicineDetailsPage";
	}
	
}
